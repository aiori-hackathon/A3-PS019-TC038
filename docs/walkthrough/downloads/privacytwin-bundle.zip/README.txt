PrivacyTwin evidence package

All database records in this archive were read in one transaction.
passport.json contains aggregate evidence, original review dependencies, declarations and policies.
configuration.json is the current policy; snapshots and evaluations may reference older policies.
Replay candidate scores from stored evidence with the repository verifier:
  python tools/verify_evidence.py privacytwin-bundle.zip

Raw source rows and provider credentials are excluded. Field names, declarations and reviewer text remain.
Evaluation labels are identified by their digest; the separately retained input cases are needed to rerun detection.
The bundled benchmark is synthetic regression data, not independently labelled held-out validation.
Manifest hashes check file consistency, not authenticity or the truth of a finding.
Technical evidence for human review. No legal compliance determination.
